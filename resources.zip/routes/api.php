<?php

use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\PasswordResetController;
use App\Http\Controllers\Api\ProfileController;
use App\Http\Controllers\Api\VerificationController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::post('login', [AuthController::class, 'login']);
//Route::post('change-status-priority', [AuthController::class, 'changeStatusPriority']);
Route::post('register', [AuthController::class, 'register']);
Route::get('/email/resend', [VerificationController::class, 'resend'])->name('verification.resend');
Route::get('/email/verify/{id}/{hash}', [VerificationController::class, 'verify'])->name('verification.verify');
Route::group(['prefix' => 'password'], function () {
    Route::post('email', [PasswordResetController::class, 'sendResetLinkEmail']);
    Route::post('reset', [PasswordResetController::class, 'reset']);
});
// Route::get('/profile',[AuthController::class, 'profile']);

Route::middleware(['auth:api'])->group(function () {
    Route::get('/logout', [AuthController::class, 'logout']);
    Route::middleware(['verified'])->group(function () {
        Route::group(['prefix' => 'profile'], function () {
            Route::get('/', [ProfileController::class, 'getUser']);
            Route::get('/permission',[ProfileController::class, 'getPermission']);
            Route::post('/change-password', [ProfileController::class, 'changePassword']);
            Route::put('/update', [ProfileController::class, 'update']);
        });

        Route::group(['prefix' => 'event'], function () {
            Route::get('', [\App\Http\Controllers\Api\EventController::class, 'index']);
            Route::get('/data', [\App\Http\Controllers\Api\EventController::class, 'eventFiller']);
            Route::get('/summary', [\App\Http\Controllers\Api\EventController::class, 'summary']);
            Route::get('/task-summary', [\App\Http\Controllers\Api\TaskController::class, 'taskSummary']);
            Route::get('/recent-events', [\App\Http\Controllers\Api\EventController::class, 'recentEvents']);
            Route::post('/change-status', [\App\Http\Controllers\Api\EventController::class, 'changeStatus']);
            Route::post('/change-priority', [\App\Http\Controllers\Api\EventController::class, 'changePriority']);
            Route::post('/create', [\App\Http\Controllers\Api\EventController::class, 'store']);
            Route::post('/order', [\App\Http\Controllers\Api\EventController::class, 'order']);
            Route::get('/favourite', [\App\Http\Controllers\Api\EventController::class, 'favourites']);
            Route::post('/{event}/favourite', [\App\Http\Controllers\Api\EventController::class, 'makeFavourite']);
            Route::get('/{event}', [\App\Http\Controllers\Api\EventController::class, 'show']);
            Route::put('/{event}/update', [\App\Http\Controllers\Api\EventController::class, 'update']);
            Route::delete('/{event}/delete', [\App\Http\Controllers\Api\EventController::class, 'destroy']);
        });

        Route::group(['prefix' => 'function'], function () {
            Route::get('', [\App\Http\Controllers\Api\FunctionController::class, 'index']);
            Route::get('/wedding', [\App\Http\Controllers\Api\FunctionController::class, 'showByName']);
            Route::post('/change-status', [\App\Http\Controllers\Api\FunctionController::class, 'changeStatus']);
            Route::post('/change-priority', [\App\Http\Controllers\Api\FunctionController::class, 'changePriority']);
            Route::post('/create', [\App\Http\Controllers\Api\FunctionController::class, 'store']);
            Route::post('/order', [\App\Http\Controllers\Api\FunctionController::class, 'order']);
            Route::get('/{function}', [\App\Http\Controllers\Api\FunctionController::class, 'show']);
            Route::put('/{function}/update', [\App\Http\Controllers\Api\FunctionController::class, 'update']);
            Route::delete('/{function}/delete', [\App\Http\Controllers\Api\FunctionController::class, 'destroy']);
        });

        Route::group(['prefix' => 'role'], function () {
            Route::get('', [\App\Http\Controllers\Api\RoleController::class, 'index']);
            Route::post('/create', [\App\Http\Controllers\Api\RoleController::class, 'create']);
            Route::post('/store', [\App\Http\Controllers\Api\RoleController::class, 'store']);
            Route::get('/{role}', [\App\Http\Controllers\Api\RoleController::class, 'show']);
            Route::put('/{role}/edit', [\App\Http\Controllers\Api\RoleController::class, 'edit']);
            Route::put('/{role}/update', [\App\Http\Controllers\Api\RoleController::class, 'update']);
            Route::delete('/{role}/delete', [\App\Http\Controllers\Api\RoleController::class, 'destroy']);
            Route::get('/hasPermission/{permission}', [\App\Http\Controllers\Api\RoleController::class], 'permissions');
        });

        Route::group(['prefix' => 'task'], function () {
            Route::get('', [\App\Http\Controllers\Api\TaskController::class, 'index']);
            Route::post('/change-status', [\App\Http\Controllers\Api\TaskController::class, 'changeStatus']);
            Route::post('/change-priority', [\App\Http\Controllers\Api\TaskController::class, 'changePriority']);
            Route::post('/create', [\App\Http\Controllers\Api\TaskController::class, 'store']);
            Route::post('/order', [\App\Http\Controllers\Api\TaskController::class, 'order']);
            Route::get('/dashboard', [\App\Http\Controllers\Api\TaskController::class, 'dashboardTasks']);
            Route::get('/{task}', [\App\Http\Controllers\Api\TaskController::class, 'show']);
            Route::put('/{task}/update', [\App\Http\Controllers\Api\TaskController::class, 'update']);
            Route::delete('/{task}/delete', [\App\Http\Controllers\Api\TaskController::class, 'destroy']);
        });

        Route::group(['prefix' => 'vendor'], function () {
            Route::get('', [\App\Http\Controllers\Api\VendorController::class, 'index']);
            Route::post('/create', [\App\Http\Controllers\Api\VendorController::class, 'store']);
            Route::get('/{vendor}', [\App\Http\Controllers\Api\VendorController::class, 'show']);
            Route::get('/{vendor}', [\App\Http\Controllers\Api\VendorController::class, 'show']);
            Route::get('/{vendor}/task', [\App\Http\Controllers\Api\VendorController::class, 'tasks']);
            Route::put('/{vendor}/update', [\App\Http\Controllers\Api\VendorController::class, 'update']);
            Route::delete('/{vendor}/delete', [\App\Http\Controllers\Api\VendorController::class, 'destroy']);
        });

        Route::group(['prefix' => 'client'], function () {
            Route::get('', [\App\Http\Controllers\Api\ClientController::class, 'index']);
            Route::post('/create', [\App\Http\Controllers\Api\ClientController::class, 'store']);
            Route::get('/{client}', [\App\Http\Controllers\Api\ClientController::class, 'show']);
            Route::put('/{client}/update', [\App\Http\Controllers\Api\ClientController::class, 'update']);
            Route::delete('/{client}/delete', [\App\Http\Controllers\Api\ClientController::class, 'destroy']);
        });

        Route::group(['prefix' => 'venue'], function () {
            Route::get('', [\App\Http\Controllers\Api\VenueController::class, 'index']);
            Route::post('/create', [\App\Http\Controllers\Api\VenueController::class, 'store']);
            Route::get('/{venue}', [\App\Http\Controllers\Api\VenueController::class, 'show']);
            Route::put('/{venue}/update', [\App\Http\Controllers\Api\VenueController::class, 'update']);
            Route::delete('/{venue}/delete', [\App\Http\Controllers\Api\VenueController::class, 'destroy']);
        });

        Route::group(['prefix' => 'my-day'], function () {
            Route::get('worklist', [\App\Http\Controllers\Api\MydayController::class, 'worklist']);
            Route::get('calender', [\App\Http\Controllers\Api\MydayController::class, 'myCalender']);
        });

        Route::post('file/upload', [\App\Http\Controllers\Api\EventController::class, 'fileUpload']);

        Route::group(['prefix' => 'setup'], function () {
            Route::get('', [\App\Http\Controllers\Api\SetupController::class, 'index']);
        });
    });
});
