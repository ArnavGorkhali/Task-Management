<?php

namespace Database\Seeders;

// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash; // Add this line

class DatabaseSeeder extends Seeder
{
<<<<<<< HEAD
public function run(){// \App\Models\User::factory(10)->create();

    $this->call([
        // UserSeeder::class,
        PermissionsSeeder::class,
   ]);
=======

public function run(){// \App\Models\User::factory(10)->create();

        \App\Models\User::create([
            'name' => 'nischal',
            'email' => 'nischal@nischal.com',
            'password' => Hash::make('nischal')
        ]);
>>>>>>> ab85a379470447b08aa0a85334a8610d640736ce
    }
}