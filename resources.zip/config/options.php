<?php

return [
    'vendor_categories' => [
        'Banquet',
        'Photography',
        'Catering',
        'Pandit',
        'Audio/Visual',
        'Technical',
        'Florist',
        'Cook',
        'Printing press',
        'Decorator',
        'Logistics',
        'Designer',
        'Rental Shop',
        'Security',
        'Drinks and Beverages'
    ],
    'event_status' => [
        'complete',
        'incomplete'
    ],
    'event_priority' => [
        'high',
        'low'
    ]
];